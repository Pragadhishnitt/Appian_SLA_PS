"""
Duration Prediction Model Training
Predicts activity completion time (regression model)
"""

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import optuna
import joblib
import json
from typing import Dict, Any, List
from tqdm import tqdm
from gpu_utils import get_cached_device_params
import warnings
warnings.filterwarnings('ignore')

class DurationModelTrainer:
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.model = None
        self.best_params = None
        self.feature_names = None
        self.device_params = get_cached_device_params()  # GPU/CPU detection
        
    def prepare_duration_data(self, events_df: pd.DataFrame, cases_df: pd.DataFrame):
        """Prepare training data for duration prediction"""
        
        # Calculate actual durations from ASSIGNED->COMPLETED pairs
        duration_data = []
        
        events_df = events_df.sort_values(['case_id', 'timestamp'])
        
        # Disabled progress bar to avoid memory issues in Colab
        for case_id in tqdm(events_df['case_id'].unique(), desc="Preparing Duration Data", disable=True):
            case_events = events_df[events_df['case_id'] == case_id]
            
            assigned_events = case_events[case_events['status'] == 'ASSIGNED']
            completed_events = case_events[case_events['status'] == 'COMPLETED']
            
            for _, assigned_row in assigned_events.iterrows():
                activity = assigned_row['activity']
                resource = assigned_row['resource']
                assigned_time = assigned_row['timestamp']
                
                # Find matching completed event
                matching_completed = completed_events[
                    (completed_events['activity'] == activity) &
                    (completed_events['timestamp'] > assigned_time)
                ]
                
                if not matching_completed.empty:
                    completed_row = matching_completed.iloc[0]
                    duration_hours = (
                        pd.to_datetime(completed_row['timestamp']) - 
                        pd.to_datetime(assigned_row['timestamp'])
                    ).total_seconds() / 3600
                    
                    # Get case attributes
                    case_info = cases_df[cases_df['case_id'] == case_id].iloc[0]
                    
                    duration_data.append({
                        'case_id': case_id,
                        'activity': activity,
                        'resource': resource,
                        'duration_hours': duration_hours,
                        'customer_tier': case_info['customer_tier'],
                        'loan_amount': case_info['loan_amount'],
                        'region': case_info['region'],
                        'complexity_score': case_info['complexity_score'],
                        'assigned_hour': pd.to_datetime(assigned_time).hour,
                        'assigned_day_of_week': pd.to_datetime(assigned_time).dayofweek,
                        'assigned_month': pd.to_datetime(assigned_time).month,
                        'priority': assigned_row['priority']
                    })
        
        return pd.DataFrame(duration_data)
    
    def create_duration_features(self, df: pd.DataFrame) -> tuple[pd.DataFrame, List[str]]:
        """Create features for duration prediction"""
        
        df = df.copy()
        
        # Encode categorical variables
        activity_map = {
            "Submit Application": 0, "Check Credit": 1, "Manual Review": 2,
            "Quality Assurance": 3, "Approve": 4, "Reject": 5
        }
        tier_map = {'Bronze': 0, 'Silver': 1, 'Gold': 2, 'Platinum': 3}
        region_map = {'North': 0, 'South': 1, 'East': 2, 'West': 3}
        
        df['activity_encoded'] = df['activity'].map(activity_map)
        df['tier_encoded'] = df['customer_tier'].map(tier_map)
        df['region_encoded'] = df['region'].map(region_map)
        
        # ========== NEW: Activity Base Durations (from process config, NOT from data) ==========
        # These are the EXPECTED durations defined in the process, not computed from target
        activity_base_duration = {
            "Submit Application": 0.1,
            "Check Credit": 2.0,
            "Manual Review": 4.0,
            "Quality Assurance": 1.5,
            "Approve": 0.5,
            "Reject": 0.3
        }
        df['activity_base_duration'] = df['activity'].map(activity_base_duration)
        
        # ========== NEW: Complexity Modifier ==========
        # Higher complexity = longer duration (multiplicative effect)
        df['complexity_duration_modifier'] = 1.0 + (df['complexity_score'] - 5) * 0.1
        df['expected_duration'] = df['activity_base_duration'] * df['complexity_duration_modifier']
        
        # ========== NEW: Time-based Workload Proxy ==========
        # Estimate workload without looking at actual data
        # Business hours have more work = potentially slower
        df['workload_proxy'] = 1.0
        df.loc[df['assigned_hour'].between(9, 11), 'workload_proxy'] = 1.3  # Morning rush
        df.loc[df['assigned_hour'].between(14, 16), 'workload_proxy'] = 1.2  # Afternoon busy
        df.loc[df['assigned_hour'] < 7, 'workload_proxy'] = 0.8  # Night = less backlog
        df.loc[df['assigned_hour'] > 19, 'workload_proxy'] = 0.8  # Evening = less backlog
        
        # ========== NEW: Tier Priority Effect ==========
        # Platinum cases get prioritized = faster
        tier_speed_modifier = {'Bronze': 1.2, 'Silver': 1.1, 'Gold': 1.0, 'Platinum': 0.8}
        df['tier_speed_modifier'] = df['customer_tier'].map(tier_speed_modifier).fillna(1.0)
        
        # ========== Resource Features (no target leakage) ==========
        resource_stats = df.groupby('resource').agg({
            'activity': ['count', 'nunique']
        }).reset_index()
        resource_stats.columns = ['resource', 'resource_task_count', 'resource_activity_variety']
        df = df.merge(resource_stats, on='resource', how='left')
        
        # Activity frequency (how often this activity type appears)
        activity_counts = df.groupby('activity').size().reset_index(name='activity_frequency')
        df = df.merge(activity_counts, on='activity', how='left')
        
        # ========== Time-based features ==========
        df['is_weekend'] = (df['assigned_day_of_week'] >= 5).astype(int)
        df['is_business_hours'] = ((df['assigned_hour'] >= 9) & (df['assigned_hour'] <= 17)).astype(int)
        df['is_peak_hour'] = ((df['assigned_hour'] >= 10) & (df['assigned_hour'] <= 15)).astype(int)
        df['is_night_shift'] = ((df['assigned_hour'] < 6) | (df['assigned_hour'] > 22)).astype(int)
        
        # ========== NEW: Day of Week Effect ==========
        # Monday/Friday often have different patterns
        df['is_monday'] = (df['assigned_day_of_week'] == 0).astype(int)
        df['is_friday'] = (df['assigned_day_of_week'] == 4).astype(int)
        
        # ========== Interaction Features ==========
        df['complexity_x_activity'] = df['complexity_score'] * df['activity_encoded']
        df['loan_amount_log'] = np.log1p(df['loan_amount'])
        df['priority_x_complexity'] = df['priority'] * df['complexity_score']
        df['expected_x_workload'] = df['expected_duration'] * df['workload_proxy']
        
        # ========== Feature Selection ==========
        feature_cols = [
            # Core features
            'activity_encoded', 'tier_encoded', 'region_encoded', 'complexity_score', 'priority',
            # Time features
            'assigned_hour', 'assigned_day_of_week', 'assigned_month',
            'is_weekend', 'is_business_hours', 'is_peak_hour', 'is_night_shift',
            'is_monday', 'is_friday',
            # Process knowledge features (from config, not data)
            'activity_base_duration', 'expected_duration', 'complexity_duration_modifier',
            # Workload proxies
            'workload_proxy', 'tier_speed_modifier',
            # Resource features
            'resource_task_count', 'resource_activity_variety', 'activity_frequency',
            # Interactions
            'complexity_x_activity', 'loan_amount_log', 'priority_x_complexity', 'expected_x_workload'
        ]
        
        # Fill missing values
        df[feature_cols] = df[feature_cols].fillna(0)
        
        return df[feature_cols], feature_cols
    
    def objective(self, trial, X_train, y_train):
        """Optuna objective for duration model"""
        
        param = {
            'objective': 'reg:squarederror',
            'eval_metric': ['rmse', 'mae'],
            **self.device_params,  # GPU/CPU settings
            'eta': trial.suggest_float('eta', 0.01, 0.3, log=True),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
            'subsample': trial.suggest_float('subsample', 0.6, 1.0),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
            'gamma': trial.suggest_float('gamma', 0, 5),
            'lambda': trial.suggest_float('lambda', 0, 5),
            'alpha': trial.suggest_float('alpha', 0, 5),
            'random_state': self.random_state,
            'n_jobs': -1
        }
        
        # Cross-validation
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=self.random_state)
        cv_scores = []
        
        # For regression, we'll use quantile-based binning for stratification
        y_bins = pd.qcut(y_train, q=5, labels=False, duplicates='drop')
        
        for train_idx, val_idx in cv.split(X_train, y_bins):
            X_train_fold, X_val_fold = X_train.iloc[train_idx], X_train.iloc[val_idx]
            y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]
            
            dtrain = xgb.DMatrix(X_train_fold, label=y_train_fold)
            dval = xgb.DMatrix(X_val_fold, label=y_val_fold)
            
            model = xgb.train(
                param,
                dtrain,
                num_boost_round=1000,
                evals=[(dval, 'validation')],
                early_stopping_rounds=50,
                verbose_eval=False
            )
            
            preds = model.predict(dval)
            mae = mean_absolute_error(y_val_fold, preds)
            cv_scores.append(mae)
        
        return np.mean(cv_scores)
    
    def optimize_hyperparameters(self, X_train, y_train, n_trials: int = 50):
        """Run hyperparameter optimization"""
        print("🔍 Optimizing duration model hyperparameters...")
        
        study = optuna.create_study(
            direction='minimize',
            sampler=optuna.samplers.TPESampler(seed=self.random_state)
        )
        
        study.optimize(
            lambda trial: self.objective(trial, X_train, y_train),
            n_trials=n_trials,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        print(f"✅ Best MAE: {study.best_value:.4f}")
        print(f"🎯 Best params: {self.best_params}")
        
        return study
    
    def train_model(self, X_train, y_train, X_test, y_test):
        """Train final duration model"""
        if self.best_params is None:
            raise ValueError("Must run hyperparameter optimization first")
        
        print("🚀 Training duration model...")
        
        final_params = self.best_params.copy()
        final_params.update({
            'objective': 'reg:squarederror',
            'eval_metric': ['rmse', 'mae'],
            **self.device_params,  # Dynamic GPU/CPU from detection
            'random_state': self.random_state,
            'n_jobs': -1
        })
        
        dtrain = xgb.DMatrix(X_train, label=y_train, feature_names=X_train.columns.tolist())
        dtest = xgb.DMatrix(X_test, label=y_test, feature_names=X_test.columns.tolist())
        
        self.model = xgb.train(
            final_params,
            dtrain,
            num_boost_round=2000,
            evals=[(dtrain, 'train'), (dtest, 'test')],
            early_stopping_rounds=100,
            verbose_eval=50
        )
        
        self.feature_names = X_train.columns.tolist()
        
        return self.model
    
    def evaluate_model(self, X_test, y_test):
        """Evaluate duration model"""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        dtest = xgb.DMatrix(X_test, feature_names=self.feature_names)
        y_pred = self.model.predict(dtest)
        
        metrics = {
            'mae': mean_absolute_error(y_test, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'r2': r2_score(y_test, y_pred),
            'mean_actual_duration': np.mean(y_test),
            'mean_predicted_duration': np.mean(y_pred)
        }
        
        print(f"📊 Duration Model Evaluation:")
        print(f"   MAE: {metrics['mae']:.4f} hours")
        print(f"   RMSE: {metrics['rmse']:.4f} hours")
        print(f"   R²: {metrics['r2']:.4f}")
        print(f"   Mean Actual: {metrics['mean_actual_duration']:.2f} hours")
        print(f"   Mean Predicted: {metrics['mean_predicted_duration']:.2f} hours")
        
        return metrics, y_pred
    
    def save_model(self, filepath: str = 'duration_model.json'):
        """Save trained model"""
        if self.model is None:
            raise ValueError("No model to save")
        
        self.model.save_model(filepath)
        
        metadata = {
            'feature_names': self.feature_names,
            'best_params': self.best_params,
            'model_type': 'Duration_Regression'
        }
        
        joblib.dump(metadata, filepath.replace('.json', '_metadata.pkl'))
        print(f"💾 Duration model saved to {filepath}")

def train_duration_pipeline():
    """Complete duration model training pipeline"""
    
    print("🏭 Loading data for duration model...")
    
    # Load data
    events_df = pd.read_csv('events_log.csv')
    cases_df = pd.read_csv('cases_table.csv')
    
    # Initialize trainer
    trainer = DurationModelTrainer()
    
    # Prepare duration data
    duration_data = trainer.prepare_duration_data(events_df, cases_df)
    print(f"📊 Prepared {len(duration_data)} duration samples")
    
    # Create features
    X, feature_names = trainer.create_duration_features(duration_data)
    y = duration_data['duration_hours']
    
    print(f"🎯 Target distribution - Mean: {y.mean():.2f}h, Std: {y.std():.2f}h")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"🎯 Training set: {X_train.shape}")
    print(f"🧪 Test set: {X_test.shape}")
    
    # Optimize hyperparameters
    trainer.optimize_hyperparameters(X_train, y_train, n_trials=30)
    
    # Train model
    model = trainer.train_model(X_train, y_train, X_test, y_test)
    
    # Evaluate model
    metrics, predictions = trainer.evaluate_model(X_test, y_test)
    
    # Save model
    trainer.save_model()
    
    return trainer, metrics

if __name__ == "__main__":
    trainer, metrics = train_duration_pipeline()
    print(f"\n🎉 Duration model training complete!")
    print(f"📈 Final MAE: {metrics['mae']:.4f} hours")
    print(f"🎯 Final R²: {metrics['r2']:.4f}")
