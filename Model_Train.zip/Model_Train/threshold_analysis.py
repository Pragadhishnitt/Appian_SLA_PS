"""
Threshold Analysis for SLA Breach Prediction
Includes:
- AUROC (threshold-independent performance)
- Brier Score (probability calibration)
- Expected Calibration Error (ECE)
- Business cost optimization
"""

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.metrics import (
    roc_curve, precision_recall_curve, roc_auc_score, 
    f1_score, precision_score, recall_score, confusion_matrix,
    brier_score_loss
)
from sklearn.calibration import calibration_curve
from typing import Dict, Tuple, List
import warnings
warnings.filterwarnings('ignore')


def calculate_ece(y_true: np.ndarray, y_proba: np.ndarray, n_bins: int = 10) -> float:
    """
    Expected Calibration Error (ECE)
    Measures how well predicted probabilities match actual frequencies.
    Lower is better. Crucial when showing "85% probability" to users.
    """
    bin_boundaries = np.linspace(0, 1, n_bins + 1)
    bin_lowers = bin_boundaries[:-1]
    bin_uppers = bin_boundaries[1:]
    
    ece = 0.0
    for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
        in_bin = (y_proba >= bin_lower) & (y_proba < bin_upper)
        prop_in_bin = in_bin.mean()
        
        if prop_in_bin > 0:
            accuracy_in_bin = y_true[in_bin].mean()
            avg_confidence_in_bin = y_proba[in_bin].mean()
            ece += np.abs(accuracy_in_bin - avg_confidence_in_bin) * prop_in_bin
    
    return ece


def calculate_calibration_summary(y_true: np.ndarray, y_proba: np.ndarray, 
                                   n_bins: int = 10) -> pd.DataFrame:
    """Generate calibration table for detailed analysis"""
    prob_true, prob_pred = calibration_curve(y_true, y_proba, n_bins=n_bins, strategy='uniform')
    
    return pd.DataFrame({
        'bin_predicted_probability': prob_pred,
        'actual_frequency': prob_true,
        'gap': np.abs(prob_pred - prob_true)
    })


class ThresholdAnalyzer:
    """Analyze and optimize prediction thresholds with calibration metrics"""
    
    DEFAULT_COSTS = {
        'false_negative_cost': 2000,
        'false_positive_cost': 150,
        'true_positive_benefit': 1000,
        'true_negative_benefit': 20
    }
    
    def __init__(self, cost_params: Dict = None):
        self.costs = cost_params or self.DEFAULT_COSTS
        self.results = {}
        self.calibration_metrics = {}
    
    def calculate_calibration_metrics(self, y_true: np.ndarray, 
                                        y_proba: np.ndarray) -> Dict:
        """
        Calculate threshold-independent calibration metrics:
        - AUROC: Discrimination ability (higher is better)
        - Brier Score: Mean squared error of probabilities (lower is better)
        - ECE: Expected Calibration Error (lower is better)
        """
        auroc = roc_auc_score(y_true, y_proba)
        brier = brier_score_loss(y_true, y_proba)
        ece = calculate_ece(y_true, y_proba)
        
        # Calibration table
        calibration_table = calculate_calibration_summary(y_true, y_proba)
        
        self.calibration_metrics = {
            'auroc': auroc,
            'brier_score': brier,
            'ece': ece,
            'calibration_table': calibration_table
        }
        
        return self.calibration_metrics
    
    def analyze_thresholds(self, y_true: np.ndarray, y_proba: np.ndarray, 
                           thresholds: np.ndarray = None) -> pd.DataFrame:
        """Analyze multiple thresholds and calculate business value"""
        if thresholds is None:
            thresholds = np.arange(0.1, 0.95, 0.05)
        
        results = []
        for thresh in thresholds:
            y_pred = (y_proba >= thresh).astype(int)
            tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
            
            precision = tp / max(1, tp + fp)
            recall = tp / max(1, tp + fn)
            f1 = 2 * precision * recall / max(0.001, precision + recall)
            
            business_value = (
                tp * self.costs['true_positive_benefit'] +
                tn * self.costs['true_negative_benefit'] -
                fp * self.costs['false_positive_cost'] -
                fn * self.costs['false_negative_cost']
            )
            
            results.append({
                'threshold': thresh,
                'precision': precision,
                'recall': recall,
                'f1_score': f1,
                'true_positives': tp,
                'false_positives': fp,
                'true_negatives': tn,
                'false_negatives': fn,
                'business_value': business_value
            })
        
        return pd.DataFrame(results)
    
    def find_optimal_thresholds(self, y_true: np.ndarray, 
                                 y_proba: np.ndarray) -> Dict[str, float]:
        """Find optimal thresholds for different strategies"""
        analysis_df = self.analyze_thresholds(y_true, y_proba)
        
        results = {
            'business_optimal': analysis_df.loc[analysis_df['business_value'].idxmax(), 'threshold'],
            'f1_optimal': analysis_df.loc[analysis_df['f1_score'].idxmax(), 'threshold'],
            'high_recall': analysis_df[analysis_df['recall'] >= 0.9]['threshold'].min() if len(analysis_df[analysis_df['recall'] >= 0.9]) > 0 else 0.3,
            'high_precision': analysis_df[analysis_df['precision'] >= 0.8]['threshold'].max() if len(analysis_df[analysis_df['precision'] >= 0.8]) > 0 else 0.7
        }
        
        self.results = results
        return results
    
    def run_analysis(self, model_path: str, X_test: pd.DataFrame, 
                     y_test: pd.Series) -> Dict:
        """Complete threshold analysis with calibration metrics"""
        print("📊 Running Threshold Analysis...")
        print("=" * 50)
        
        # Load model and predict
        model = xgb.Booster()
        model.load_model(model_path)
        dtest = xgb.DMatrix(X_test)
        y_proba = model.predict(dtest)
        
        # Calculate calibration metrics (threshold-independent)
        print("\n🎯 THRESHOLD-INDEPENDENT METRICS:")
        calibration = self.calculate_calibration_metrics(y_test.values, y_proba)
        print(f"   AUROC:       {calibration['auroc']:.4f}  (higher is better, >0.8 good)")
        print(f"   Brier Score: {calibration['brier_score']:.4f}  (lower is better, <0.25 good)")
        print(f"   ECE:         {calibration['ece']:.4f}  (lower is better, <0.1 good)")
        
        # Calibration interpretation
        if calibration['ece'] < 0.05:
            print("   ✅ Probabilities well-calibrated - safe to show to users")
        elif calibration['ece'] < 0.1:
            print("   ⚠️ Minor calibration gap - probabilities reasonably accurate")
        else:
            print("   ❌ Poor calibration - consider Platt scaling or isotonic regression")
        
        # Threshold analysis
        analysis_df = self.analyze_thresholds(y_test.values, y_proba)
        optimal = self.find_optimal_thresholds(y_test.values, y_proba)
        
        print("\n📈 OPTIMAL THRESHOLDS:")
        for strategy, thresh in optimal.items():
            row = analysis_df[analysis_df['threshold'] == thresh].iloc[0] if thresh in analysis_df['threshold'].values else None
            if row is not None:
                print(f"   {strategy}: {thresh:.2f} (F1={row['f1_score']:.3f}, Value=${row['business_value']:,.0f})")
            else:
                print(f"   {strategy}: {thresh:.2f}")
        
        # Calibration table
        print("\n📋 CALIBRATION TABLE:")
        print(calibration['calibration_table'].to_string(index=False))
        
        return {
            'auroc': calibration['auroc'],
            'brier_score': calibration['brier_score'],
            'ece': calibration['ece'],
            'calibration_table': calibration['calibration_table'],
            'optimal_thresholds': optimal,
            'analysis_table': analysis_df,
            'recommended_threshold': optimal['business_optimal']
        }


def run_threshold_analysis(model_path: str = 'sla_model.json',
                           events_path: str = 'events_log.csv',
                           cases_path: str = 'cases_table.csv') -> Dict:
    """Standalone threshold analysis function"""
    from feature_engineering import ProcessFeatureEngineer
    from train_sla_model import SLAModelTrainer
    from sklearn.model_selection import train_test_split
    
    print("🔍 Loading data...")
    events_df = pd.read_csv(events_path)
    cases_df = pd.read_csv(cases_path)
    
    print("🔧 Engineering base features...")
    fe = ProcessFeatureEngineer()
    df, base_feature_cols = fe.create_feature_matrix(events_df, cases_df)
    
    training_data = df[df['status'] == 'ASSIGNED'].copy()
    
    # Apply SLA-specific features (same as training)
    print("🔧 Adding SLA-specific features...")
    sla_trainer = SLAModelTrainer()
    X, feature_cols = sla_trainer.create_sla_features(training_data, base_feature_cols)
    y = training_data['will_breach_sla']
    
    _, X_test, _, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    analyzer = ThresholdAnalyzer()
    return analyzer.run_analysis(model_path, X_test, y_test)


if __name__ == "__main__":
    results = run_threshold_analysis()
    print(f"\n✅ Recommended threshold: {results['recommended_threshold']:.2f}")
    print(f"   With AUROC: {results['auroc']:.4f}, ECE: {results['ece']:.4f}")
