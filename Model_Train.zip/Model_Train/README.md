# Appian XGBoost Model Training

Complete ML pipeline for training, inference, and threshold optimization.

## 🚀 Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run complete pipeline (data → train → analyze → test → export)
python pipeline.py --all
```

## Pipeline Stages

| Stage | Flag | Description |
|-------|------|-------------|
| 1 | `--generate` | Generate training data (all 4 variability factors) |
| 2 | `--train` | Train 3 XGBoost models |
| 3 | `--threshold` | Find optimal SLA threshold |
| 4 | `--inference` | Test predictions on sample data |
| 5 | `--export` | Copy models to `../weights/xgboost/v1/` |

## Usage Examples

```bash
# Full pipeline
python pipeline.py --all

# Full pipeline with more data
python pipeline.py --all --cases 20000

# Individual stages
python pipeline.py --generate
python pipeline.py --train
python pipeline.py --threshold
python pipeline.py --inference
python pipeline.py --export

# Multiple stages
python pipeline.py --generate --train
```

## Models

| Model | Type | Output |
|-------|------|--------|
| Duration | Regression | `duration_model.json` |
| Routing | Multi-class | `routing_model.json` |
| SLA Breach | Binary | `sla_model.json` |

## Variability Factors

All 4 factors from the problem statement are included:
1. ✅ Volume Spikes (non-homogeneous Poisson)
2. ✅ Workforce Variability (shift schedules, sick agents)
3. ✅ Case Complexity (duration modifiers)
4. ✅ Concept Drift (Month 4+ slowdown)

## Files

| File | Purpose |
|------|---------|
| `pipeline.py` | **Main entry point** - run this |
| `data_generation.py` | Unified data generator |
| `train_all_models.py` | Training orchestrator |
| `threshold_analysis.py` | Threshold optimization |
| `multi_model_inference.py` | Inference engine |
| `feature_engineering.py` | Feature extraction |

## Outputs

After `python pipeline.py --all`:
- `cases_table.csv`, `events_log.csv` (data)
- `duration_model.json`, `routing_model.json`, `sla_model.json` (models)
- `optimal_threshold.txt` (recommended threshold)
- `../weights/xgboost/v1/` (exported for inference service)
