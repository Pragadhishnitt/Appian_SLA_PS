"""
Routing Prediction Model Training
Predicts next activity in the process (classification model)
"""

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score)
from sklearn.preprocessing import LabelEncoder
import optuna
import joblib
from typing import List
from tqdm import tqdm
from gpu_utils import get_cached_device_params
import warnings
warnings.filterwarnings('ignore')

class RoutingModelTrainer:
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.model = None
        self.best_params = None
        self.feature_names = None
        self.label_encoder = LabelEncoder()
        self.activity_mapping = None
        self.device_params = get_cached_device_params()  # GPU/CPU detection
        
    def prepare_routing_data(self, events_df: pd.DataFrame, cases_df: pd.DataFrame):
        """Prepare training data for next activity prediction"""
        
        routing_data = []
        
        # Sort events to maintain process order
        events_df = events_df.sort_values(['case_id', 'timestamp'])
        
        # Disabled progress bar to avoid memory issues in Colab
        for case_id in tqdm(events_df['case_id'].unique(), desc="Preparing Routing Data", disable=True):
            case_events = events_df[events_df['case_id'] == case_id].copy()
            case_events = case_events.reset_index(drop=True)
            
            # Get case attributes
            case_info = cases_df[cases_df['case_id'] == case_id].iloc[0]
            
            # Create sequences for each position in the process
            for i in range(len(case_events) - 1):
                current_event = case_events.iloc[i]
                next_event = case_events.iloc[i + 1]
                
                # Only predict from completed events to next assigned events
                if current_event['status'] == 'COMPLETED' and next_event['status'] == 'ASSIGNED':
                    
                    # Get previous activities context
                    prev_activities = case_events.iloc[:i+1]['activity'].tolist()
                    
                    routing_data.append({
                        'case_id': case_id,
                        'current_activity': current_event['activity'],
                        'next_activity': next_event['activity'],
                        'position_in_process': i + 1,
                        'total_activities': len(case_events),
                        'progress_ratio': (i + 1) / len(case_events),
                        'prev_activities': '|'.join(prev_activities[-3:]),  # Last 3 activities
                        'customer_tier': case_info['customer_tier'],
                        'loan_amount': case_info['loan_amount'],
                        'region': case_info['region'],
                        'complexity_score': case_info['complexity_score'],
                        'resource': current_event['resource'],
                        'timestamp': current_event['timestamp'],
                        'priority': current_event['priority']
                    })
        
        return pd.DataFrame(routing_data)
    
    def create_routing_features(self, df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series, List[str]]:
        """Create features for routing prediction. Returns (X, y, feature_cols)"""
        
        df = df.copy()
        
        # Encode target variable (next activity)
        df['next_activity_encoded'] = self.label_encoder.fit_transform(df['next_activity'])
        self.activity_mapping = dict(zip(
            self.label_encoder.classes_, 
            self.label_encoder.transform(self.label_encoder.classes_)
        ))
        
        # Encode categorical variables
        current_activity_map = {
            "Submit Application": 0, "Check Credit": 1, "Manual Review": 2,
            "Quality Assurance": 3, "Approve": 4, "Reject": 5
        }
        tier_map = {'Bronze': 0, 'Silver': 1, 'Gold': 2, 'Platinum': 3}
        region_map = {'North': 0, 'South': 1, 'East': 2, 'West': 3}
        
        df['current_activity_encoded'] = df['current_activity'].map(current_activity_map)
        df['tier_encoded'] = df['customer_tier'].map(tier_map)
        df['region_encoded'] = df['region'].map(region_map)
        
        # Time-based features
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df['hour_of_day'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        df['month'] = df['timestamp'].dt.month
        df['is_weekend'] = (df['timestamp'].dt.dayofweek >= 5).astype(int)
        df['is_business_hours'] = ((df['timestamp'].dt.hour >= 9) & (df['timestamp'].dt.hour <= 17)).astype(int)
        
        # Process context features (only past-looking features)
        df['is_start_of_process'] = (df['position_in_process'] == 1).astype(int)
        # NOTE: Removed 'is_end_of_process' and 'activities_remaining' - they leak future info
        
        # Resource experience features (no target leakage - just count of samples per resource)
        resource_counts = df.groupby('resource').size().reset_index(name='resource_sample_count')
        df = df.merge(resource_counts, on='resource', how='left')
        
        # NOTE: Removed 'transition_probability' - it was computed using next_activity (the target!)
        # This was causing 100% accuracy due to severe data leakage
        
        # Case complexity interactions
        df['complexity_x_position'] = df['complexity_score'] * df['position_in_process']
        df['loan_amount_log'] = np.log1p(df['loan_amount'])
        
        # Previous activity patterns (simplified)
        df['prev_activity_count'] = df['prev_activities'].apply(lambda x: len(x.split('|')) if x else 0)
        
        # Select feature columns (removed leaky features)
        # REMOVED: total_activities, is_end_of_process, activities_remaining (future info)
        # REMOVED: transition_probability, unique_next_activities (target leakage)
        feature_cols = [
            'current_activity_encoded', 'tier_encoded', 'region_encoded', 'complexity_score',
            'position_in_process', 'progress_ratio', 'priority',
            'hour_of_day', 'day_of_week', 'month', 'is_weekend', 'is_business_hours',
            'is_start_of_process', 'resource_sample_count',
            'complexity_x_position', 'loan_amount_log', 'prev_activity_count'
        ]
        
        # Fill missing values
        df[feature_cols] = df[feature_cols].fillna(0)
        
        # Return X, y, and feature_cols
        return df[feature_cols], df['next_activity_encoded'], feature_cols
    
    def objective(self, trial, X_train, y_train):
        """Optuna objective for routing model"""
        
        param = {
            'objective': 'multi:softprob',
            'eval_metric': ['mlogloss', 'merror'],
            'num_class': len(self.label_encoder.classes_),
            **self.device_params,  # GPU/CPU settings
            'eta': trial.suggest_float('eta', 0.01, 0.3, log=True),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
            'subsample': trial.suggest_float('subsample', 0.6, 1.0),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
            'gamma': trial.suggest_float('gamma', 0, 5),
            'lambda': trial.suggest_float('lambda', 0, 5),
            'alpha': trial.suggest_float('alpha', 0, 5),
            'random_state': self.random_state,
            'n_jobs': -1
        }
        
        # Cross-validation
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=self.random_state)
        cv_scores = []
        
        for train_idx, val_idx in cv.split(X_train, y_train):
            X_train_fold, X_val_fold = X_train.iloc[train_idx], X_train.iloc[val_idx]
            y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]
            
            dtrain = xgb.DMatrix(X_train_fold, label=y_train_fold)
            dval = xgb.DMatrix(X_val_fold, label=y_val_fold)
            
            model = xgb.train(
                param,
                dtrain,
                num_boost_round=1000,
                evals=[(dval, 'validation')],
                early_stopping_rounds=50,
                verbose_eval=False
            )
            
            preds = model.predict(dval)
            pred_classes = np.argmax(preds, axis=1)
            accuracy = accuracy_score(y_val_fold, pred_classes)
            cv_scores.append(accuracy)
        
        return np.mean(cv_scores)
    
    def optimize_hyperparameters(self, X_train, y_train, n_trials: int = 50):
        """Run hyperparameter optimization"""
        print("🔍 Optimizing routing model hyperparameters...")
        
        study = optuna.create_study(
            direction='maximize',
            sampler=optuna.samplers.TPESampler(seed=self.random_state)
        )
        
        study.optimize(
            lambda trial: self.objective(trial, X_train, y_train),
            n_trials=n_trials,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        print(f"✅ Best Accuracy: {study.best_value:.4f}")
        print(f"🎯 Best params: {self.best_params}")
        
        return study
    
    def train_model(self, X_train, y_train, X_test, y_test):
        """Train final routing model"""
        if self.best_params is None:
            raise ValueError("Must run hyperparameter optimization first")
        
        print("🚀 Training routing model...")
        
        final_params = self.best_params.copy()
        final_params.update({
            'objective': 'multi:softprob',
            'eval_metric': ['mlogloss', 'merror'],
            'num_class': len(self.label_encoder.classes_),
            **self.device_params,  # GPU/CPU settings
            'random_state': self.random_state,
            'n_jobs': -1
        })
        
        dtrain = xgb.DMatrix(X_train, label=y_train, feature_names=X_train.columns.tolist())
        dtest = xgb.DMatrix(X_test, label=y_test, feature_names=X_test.columns.tolist())
        
        self.model = xgb.train(
            final_params,
            dtrain,
            num_boost_round=2000,
            evals=[(dtrain, 'train'), (dtest, 'test')],
            early_stopping_rounds=100,
            verbose_eval=50
        )
        
        self.feature_names = X_train.columns.tolist()
        
        return self.model
    
    def evaluate_model(self, X_test, y_test):
        """Evaluate routing model"""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        dtest = xgb.DMatrix(X_test, feature_names=self.feature_names)
        y_pred_proba = self.model.predict(dtest)
        y_pred = np.argmax(y_pred_proba, axis=1)
        
        # Convert back to original labels for interpretation
        # y_test_labels = self.label_encoder.inverse_transform(y_test)  # Commented as unused
        y_pred_labels = self.label_encoder.inverse_transform(y_pred)
        
        metrics = {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision_macro': precision_score(y_test, y_pred, average='macro'),
            'recall_macro': recall_score(y_test, y_pred, average='macro'),
            'f1_macro': f1_score(y_test, y_pred, average='macro'),
            'num_classes': len(self.label_encoder.classes_),
            'class_distribution': dict(zip(self.label_encoder.classes_, np.bincount(y_test)))
        }
        
        print("📊 Routing Model Evaluation:")
        print(f"   Accuracy: {metrics['accuracy']:.4f}")
        print(f"   Macro Precision: {metrics['precision_macro']:.4f}")
        print(f"   Macro Recall: {metrics['recall_macro']:.4f}")
        print(f"   Macro F1: {metrics['f1_macro']:.4f}")
        print(f"   Classes: {self.label_encoder.classes_.tolist()}")
        
        # Show classification report
        print("\n📋 Classification Report:")
        # print(classification_report(y_test_labels, y_pred_labels))  # Commented as unused
        
        return metrics, y_pred_labels, y_pred_proba
    
    def save_model(self, filepath: str = 'routing_model.json'):
        """Save trained model"""
        if self.model is None:
            raise ValueError("No model to save")
        
        self.model.save_model(filepath)
        
        metadata = {
            'feature_names': self.feature_names,
            'best_params': self.best_params,
            'model_type': 'Routing_MultiClass',
            'label_encoder_classes': self.label_encoder.classes_.tolist(),
            'activity_mapping': self.activity_mapping
        }
        
        joblib.dump(metadata, filepath.replace('.json', '_metadata.pkl'))
        print(f"💾 Routing model saved to {filepath}")

def train_routing_pipeline():
    """Complete routing model training pipeline"""
    
    print("🏭 Loading data for routing model...")
    
    # Load data
    events_df = pd.read_csv('events_log.csv')
    cases_df = pd.read_csv('cases_table.csv')
    
    # Initialize trainer
    trainer = RoutingModelTrainer()
    
    # Prepare routing data
    routing_data = trainer.prepare_routing_data(events_df, cases_df)
    print(f"📊 Prepared {len(routing_data)} routing samples")
    print(f"🎯 Activity distribution: {routing_data['next_activity'].value_counts().to_dict()}")
    
    # Create features (returns X, y, feature_cols)
    X, y, feature_names = trainer.create_routing_features(routing_data)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"🎯 Training set: {X_train.shape}")
    print(f"🧪 Test set: {X_test.shape}")
    
    # Optimize hyperparameters
    trainer.optimize_hyperparameters(X_train, y_train, n_trials=30)
    
    # Train model
    trainer.train_model(X_train, y_train, X_test, y_test)
    
    # Evaluate model
    metrics, predictions, probabilities = trainer.evaluate_model(X_test, y_test)
    
    # Save model
    trainer.save_model()
    
    return trainer, metrics

if __name__ == "__main__":
    trainer, metrics = train_routing_pipeline()
    print("\n🎉 Routing model training complete!")
    print(f"📈 Final Accuracy: {metrics['accuracy']:.4f}")
    print(f"🎯 Final F1-Score: {metrics['f1_macro']:.4f}")
