"""
Unified Training Orchestrator for All 3 Models
Trains Duration, Routing, and SLA breach models sequentially
"""

# Standard library imports
import sys
import argparse
import json
from datetime import datetime

# Third-party imports
import warnings
from sklearn.model_selection import train_test_split

# Local imports
from train_duration_model import DurationModelTrainer
from train_routing_model import RoutingModelTrainer
from train_sla_model import SLAModelTrainer
from data_generation import generate_cases_table, generate_event_log, calculate_remaining_time

warnings.filterwarnings('ignore')

class ModelTrainingOrchestrator:
    def __init__(self, config_path: str = None):
        """Initialize the training orchestrator"""
        self.config = self.load_config(config_path) if config_path else self.get_default_config()
        self.models = {}
        self.metrics = {}
        
    def load_config(self, config_path: str) -> dict:
        """Load configuration from JSON file"""
        with open(config_path, 'r') as f:
            return json.load(f)
    
    def get_default_config(self) -> dict:
        """Get default configuration"""
        return {
            "data_generation": {
                "num_cases": 10000,
                "start_date": "2024-01-01"
            },
            "training": {
                "test_size": 0.2,
                "optimize_hyperparams": True,
                "n_trials": 30,
                "random_state": 42
            },
            "models": {
                "duration": {"enabled": True, "n_trials": 30},
                "routing": {"enabled": True, "n_trials": 30},
                "sla": {"enabled": True, "n_trials": 30}
            },
            "paths": {
                "cases_file": "cases_table.csv",
                "events_file": "events_log.csv",
                "duration_model": "duration_model.json",
                "routing_model": "routing_model.json",
                "sla_model": "sla_model.json"
            }
        }
    
    def run_data_generation(self):
        """Generate synthetic data for all models"""
        print("🏭 Starting data generation...")
        
        # Generate cases and events
        cases = generate_cases_table(self.config["data_generation"]["num_cases"])
        events = generate_event_log(cases)
        events = calculate_remaining_time(events)
        
        # Save data
        cases.to_csv(self.config["paths"]["cases_file"], index=False)
        events.to_csv(self.config["paths"]["events_file"], index=False)
        
        print(f"✅ Generated {len(cases)} cases with {len(events)} events")
        print(f"📊 SLA breach rate: {events[events['status']=='COMPLETED'].groupby('case_id')['will_breach_sla'].first().mean():.2%}")
        
        return cases, events
    
    def train_duration_model(self, events_df, cases_df):
        """Train duration prediction model"""
        if not self.config["models"]["duration"]["enabled"]:
            print("⏭️ Skipping duration model (disabled)")
            return None
        
        print("\n🕐 Training Duration Model...")
        print("=" * 50)
        
        trainer = DurationModelTrainer()
        
        # Prepare duration data
        duration_data = trainer.prepare_duration_data(events_df, cases_df)
        print(f"📊 Prepared {len(duration_data)} duration samples")
        
        # Create features
        X, feature_names = trainer.create_duration_features(duration_data)
        y = duration_data['duration_hours']
        
        print(f"🎯 Target distribution - Mean: {y.mean():.2f}h, Std: {y.std():.2f}h")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=self.config["training"]["test_size"], random_state=42
        )
        
        # Optimize hyperparameters
        if self.config["training"]["optimize_hyperparams"]:
            trainer.optimize_hyperparameters(X_train, y_train, 
                                         n_trials=self.config["models"]["duration"]["n_trials"])
        
        # Train model
        trainer.train_model(X_train, y_train, X_test, y_test)
        
        # Evaluate model
        metrics, predictions = trainer.evaluate_model(X_test, y_test)
        
        # Save model
        trainer.save_model(self.config["paths"]["duration_model"])
        
        self.models['duration'] = trainer
        self.metrics['duration'] = metrics
        
        return trainer, metrics
    
    def train_routing_model(self, events_df, cases_df):
        """Train routing prediction model"""
        if not self.config["models"]["routing"]["enabled"]:
            print("⏭️ Skipping routing model (disabled)")
            return None
        
        print("\n🧭 Training Routing Model...")
        print("=" * 50)
        
        trainer = RoutingModelTrainer()
        
        # Prepare routing data
        routing_data = trainer.prepare_routing_data(events_df, cases_df)
        print(f"📊 Prepared {len(routing_data)} routing samples")
        print(f"🎯 Activity distribution: {routing_data['next_activity'].value_counts().to_dict()}")
        
        # Create features (now returns X, y, feature_cols)
        X, y, feature_names = trainer.create_routing_features(routing_data)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=self.config["training"]["test_size"], random_state=42, stratify=y
        )
        
        # Optimize hyperparameters
        if self.config["training"]["optimize_hyperparams"]:
            trainer.optimize_hyperparameters(X_train, y_train, 
                                         n_trials=self.config["models"]["routing"]["n_trials"])
        
        # Train model
        trainer.train_model(X_train, y_train, X_test, y_test)
        
        # Evaluate model
        metrics, predictions, probabilities = trainer.evaluate_model(X_test, y_test)
        
        # Save model
        trainer.save_model(self.config["paths"]["routing_model"])
        
        self.models['routing'] = trainer
        self.metrics['routing'] = metrics
        
        return trainer, metrics
    
    def train_sla_model(self, events_df, cases_df):
        """Train SLA breach prediction model"""
        if not self.config["models"]["sla"]["enabled"]:
            print("⏭️ Skipping SLA model (disabled)")
            return None
        
        print("\n⚠️ Training SLA Breach Model...")
        print("=" * 50)
        
        trainer = SLAModelTrainer()
        
        # Prepare SLA data
        training_data, base_feature_cols = trainer.prepare_sla_data(events_df, cases_df)
        print(f"📊 Prepared {len(training_data)} SLA samples")
        print(f"🎯 Target distribution: {training_data['will_breach_sla'].value_counts(normalize=True).to_dict()}")
        
        # Create enhanced features
        X, feature_cols = trainer.create_sla_features(training_data, base_feature_cols)
        y = training_data['will_breach_sla']
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=self.config["training"]["test_size"], random_state=42, stratify=y
        )
        
        print(f"🎯 Training set: {X_train.shape}")
        print(f"🧪 Test set: {X_test.shape}")
        print(f"📊 Features: {len(feature_cols)}")
        
        # Optimize hyperparameters
        if self.config["training"]["optimize_hyperparams"]:
            trainer.optimize_hyperparameters(X_train, y_train, 
                                         n_trials=self.config["models"]["sla"]["n_trials"])
        
        # Train model
        trainer.train_model(X_train, y_train, X_test, y_test)
        
        # Evaluate model
        metrics, predictions = trainer.evaluate_model(X_test, y_test)
        
        # Save model
        trainer.save_model(self.config["paths"]["sla_model"])
        
        self.models['sla'] = trainer
        self.metrics['sla'] = metrics
        
        return trainer, metrics
    
    def run_full_training(self):
        """Run training for all enabled models"""
        print("🚀 Starting Full Model Training Pipeline...")
        print(f"⏰ Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            # Step 1: Data Generation
            cases, events = self.run_data_generation()
            
            # Step 2: Train Models
            self.train_duration_model(events, cases)
            self.train_routing_model(events, cases)
            self.train_sla_model(events, cases)
            
            # Step 3: Summary Report
            self.print_training_summary()
            
            print("\n🎉 ALL MODEL TRAINING COMPLETED SUCCESSFULLY!")
            print(f"⏰ Finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            
            return True
            
        except Exception as e:
            print(f"❌ Training pipeline failed: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def print_training_summary(self):
        """Print comprehensive training summary"""
        print("\n" + "=" * 60)
        print("📊 TRAINING SUMMARY REPORT")
        print("=" * 60)
        
        # Duration Model Summary
        if 'duration' in self.metrics:
            m = self.metrics['duration']
            print("\n🕐 DURATION MODEL (Regression):")
            print(f"   📈 MAE: {m['mae']:.4f} hours")
            print(f"   📈 RMSE: {m['rmse']:.4f} hours")
            print(f"   📈 R²: {m['r2']:.4f}")
            print(f"   💾 Saved to: {self.config['paths']['duration_model']}")
        
        # Routing Model Summary
        if 'routing' in self.metrics:
            m = self.metrics['routing']
            print("\n🧭 ROUTING MODEL (Multi-Class Classification):")
            print(f"   📈 Accuracy: {m['accuracy']:.4f}")
            print(f"   📈 Macro F1: {m['f1_macro']:.4f}")
            print(f"   🎯 Classes: {m['num_classes']}")
            print(f"   💾 Saved to: {self.config['paths']['routing_model']}")
        
        # SLA Model Summary
        if 'sla' in self.metrics:
            m = self.metrics['sla']
            print("\n⚠️ SLA BREACH MODEL (Binary Classification):")
            print(f"   📈 ROC-AUC: {m['roc_auc']:.4f}")
            print(f"   📈 Accuracy: {m['accuracy']:.4f}")
            print(f"   📈 F1-Score: {m['f1']:.4f}")
            print(f"   💾 Saved to: {self.config['paths']['sla_model']}")
        
        print("\n🎯 All models are ready for inference!")
        print("📁 Model files:")
        for model_name, path in self.config["paths"].items():
            if model_name.endswith("_model"):
                print(f"   - {path}")

def main():
    """Main function to run the training orchestrator"""
    parser = argparse.ArgumentParser(description='Train All Appian ML Models')
    parser.add_argument('--config', type=str, help='Path to configuration file')
    parser.add_argument('--duration-only', action='store_true', help='Train only duration model')
    parser.add_argument('--routing-only', action='store_true', help='Train only routing model')
    parser.add_argument('--sla-only', action='store_true', help='Train only SLA model')
    
    args = parser.parse_args()
    
    # Initialize orchestrator
    orchestrator = ModelTrainingOrchestrator(args.config)
    
    # Update configuration based on arguments
    if args.duration_only:
        orchestrator.config["models"]["routing"]["enabled"] = False
        orchestrator.config["models"]["sla"]["enabled"] = False
    elif args.routing_only:
        orchestrator.config["models"]["duration"]["enabled"] = False
        orchestrator.config["models"]["sla"]["enabled"] = False
    elif args.sla_only:
        orchestrator.config["models"]["duration"]["enabled"] = False
        orchestrator.config["models"]["routing"]["enabled"] = False
    
    # Run training
    success = orchestrator.run_full_training()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
