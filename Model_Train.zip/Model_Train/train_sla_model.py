"""
SLA Breach Prediction Model Training
Predicts probability of SLA breach (binary classification model)
"""

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, 
                           roc_auc_score)
import optuna
import joblib
from typing import List
from gpu_utils import get_cached_device_params
import warnings
warnings.filterwarnings('ignore')

class SLAModelTrainer:
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.model = None
        self.best_params = None
        self.feature_names = None
        self.device_params = get_cached_device_params()  # GPU/CPU detection
        
    def prepare_sla_data(self, events_df: pd.DataFrame, cases_df: pd.DataFrame):
        """Prepare training data for SLA breach prediction"""
        
        # Use the existing feature engineering pipeline
        from feature_engineering import ProcessFeatureEngineer
        
        fe = ProcessFeatureEngineer()
        df, feature_cols = fe.create_feature_matrix(events_df, cases_df)
        
        # Only use assigned events for prediction (predicting future breaches)
        training_data = df[df['status'] == 'ASSIGNED'].copy()
        
        # Ensure we have the target variable
        if 'will_breach_sla' not in training_data.columns:
            raise ValueError("Target variable 'will_breach_sla' not found in data")
        
        return training_data, feature_cols
    
    def create_sla_features(self, df: pd.DataFrame, feature_cols: List[str]) -> tuple[pd.DataFrame, List[str]]:
        """Enhance features specifically for SLA prediction"""
        
        df = df.copy()
        
        # Additional SLA-specific features
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df['sla_deadline'] = pd.to_datetime(df['sla_deadline'])
        
        # Time-based pressure features
        df['hours_to_sla'] = (df['sla_deadline'] - df['timestamp']).dt.total_seconds() / 3600
        df['sla_urgent'] = (df['hours_to_sla'] <= 4).astype(int)
        df['sla_critical'] = (df['hours_to_sla'] <= 1).astype(int)
        df['sla_pressure_ratio'] = df['hours_to_sla'] / 24  # Normalized by 24h SLA
        
        # Workload pressure features
        df['resource_workload'] = df.groupby('resource')['case_id'].transform('count')
        df['activity_workload'] = df.groupby('activity')['case_id'].transform('count')
        
        # Case complexity interactions with time pressure
        df['complexity_x_time_pressure'] = df['complexity_score'] * (1 / (df['hours_to_sla'] + 1))
        
        # Priority and time pressure interaction
        df['priority_x_urgency'] = df['priority'] * df['sla_urgent']
        
        # Historical performance features
        activity_breach_rate = df.groupby('activity')['will_breach_sla'].transform('mean')
        resource_breach_rate = df.groupby('resource')['will_breach_sla'].transform('mean')
        
        df['activity_historical_risk'] = activity_breach_rate
        df['resource_historical_risk'] = resource_breach_rate
        
        # System-wide workload indicators
        df['total_active_cases'] = len(df)
        df['system_load_ratio'] = df['resource_workload'] / df['total_active_cases']
        
        # Add new features to the feature list
        new_features = [
            'hours_to_sla', 'sla_urgent', 'sla_critical', 'sla_pressure_ratio',
            'resource_workload', 'activity_workload', 'complexity_x_time_pressure',
            'priority_x_urgency', 'activity_historical_risk', 'resource_historical_risk',
            'total_active_cases', 'system_load_ratio'
        ]
        
        # Combine with existing features
        all_feature_cols = feature_cols + [f for f in new_features if f in df.columns]
        
        # Remove any duplicates
        all_feature_cols = list(dict.fromkeys(all_feature_cols))
        
        # Fill missing values
        df[all_feature_cols] = df[all_feature_cols].fillna(0)
        
        return df[all_feature_cols], all_feature_cols
    
    def objective(self, trial, X_train, y_train):
        """Optuna objective for SLA model"""
        
        param = {
            'objective': 'binary:logistic',
            'eval_metric': ['auc', 'logloss'],
            **self.device_params,  # GPU/CPU settings
            'eta': trial.suggest_float('eta', 0.01, 0.3, log=True),
            'max_depth': trial.suggest_int('max_depth', 3, 10),
            'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
            'subsample': trial.suggest_float('subsample', 0.6, 1.0),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
            'gamma': trial.suggest_float('gamma', 0, 5),
            'lambda': trial.suggest_float('lambda', 0, 5),
            'alpha': trial.suggest_float('alpha', 0, 5),
            'scale_pos_weight': trial.suggest_float('scale_pos_weight', 1, 10),
            'random_state': self.random_state,
            'n_jobs': -1
        }
        
        # Cross-validation
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=self.random_state)
        cv_scores = []
        
        for train_idx, val_idx in cv.split(X_train, y_train):
            X_train_fold, X_val_fold = X_train.iloc[train_idx], X_train.iloc[val_idx]
            y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]
            
            dtrain = xgb.DMatrix(X_train_fold, label=y_train_fold)
            dval = xgb.DMatrix(X_val_fold, label=y_val_fold)
            
            model = xgb.train(
                param,
                dtrain,
                num_boost_round=1000,
                evals=[(dval, 'validation')],
                early_stopping_rounds=50,
                verbose_eval=False
            )
            
            preds = model.predict(dval)
            auc = roc_auc_score(y_val_fold, preds)
            cv_scores.append(auc)
        
        return np.mean(cv_scores)
    
    def optimize_hyperparameters(self, X_train, y_train, n_trials: int = 50):
        """Run hyperparameter optimization"""
        print("🔍 Optimizing SLA model hyperparameters...")
        
        study = optuna.create_study(
            direction='maximize',
            sampler=optuna.samplers.TPESampler(seed=self.random_state)
        )
        
        study.optimize(
            lambda trial: self.objective(trial, X_train, y_train),
            n_trials=n_trials,
            show_progress_bar=True
        )
        
        self.best_params = study.best_params
        print(f"✅ Best AUC: {study.best_value:.4f}")
        print(f"🎯 Best params: {self.best_params}")
        
        return study
    
    def train_model(self, X_train, y_train, X_test, y_test):
        """Train final SLA model"""
        if self.best_params is None:
            raise ValueError("Must run hyperparameter optimization first")
        
        print("🚀 Training SLA model...")
        
        final_params = self.best_params.copy()
        final_params.update({
            'objective': 'binary:logistic',
            'eval_metric': ['auc', 'logloss'],
            **self.device_params,  # GPU/CPU settings
            'random_state': self.random_state,
            'n_jobs': -1
        })
        
        dtrain = xgb.DMatrix(X_train, label=y_train, feature_names=X_train.columns.tolist())
        dtest = xgb.DMatrix(X_test, label=y_test, feature_names=X_test.columns.tolist())
        
        self.model = xgb.train(
            final_params,
            dtrain,
            num_boost_round=2000,
            evals=[(dtrain, 'train'), (dtest, 'test')],
            early_stopping_rounds=100,
            verbose_eval=50
        )
        
        self.feature_names = X_train.columns.tolist()
        
        return self.model
    
    def evaluate_model(self, X_test, y_test, threshold: float = 0.5):
        """Evaluate SLA model"""
        if self.model is None:
            raise ValueError("Model not trained yet")
        
        dtest = xgb.DMatrix(X_test, feature_names=self.feature_names)
        y_pred_proba = self.model.predict(dtest)
        y_pred = (y_pred_proba >= threshold).astype(int)
        
        metrics = {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred),
            'recall': recall_score(y_test, y_pred),
            'f1': f1_score(y_test, y_pred),
            'roc_auc': roc_auc_score(y_test, y_pred_proba),
            'confusion_matrix': [[0, 0], [0, 0]],  # Placeholder
            'threshold': threshold
        }
        
        print(f"📊 SLA Model Evaluation (threshold={threshold}):")
        print(f"   Accuracy: {metrics['accuracy']:.4f}")
        print(f"   Precision: {metrics['precision']:.4f}")
        print(f"   Recall: {metrics['recall']:.4f}")
        print(f"   F1-Score: {metrics['f1']:.4f}")
        print(f"   ROC-AUC: {metrics['roc_auc']:.4f}")
        
        return metrics, y_pred_proba
    
    def save_model(self, filepath: str = 'sla_model.json'):
        """Save trained model"""
        if self.model is None:
            raise ValueError("No model to save")
        
        self.model.save_model(filepath)
        
        metadata = {
            'feature_names': self.feature_names,
            'best_params': self.best_params,
            'model_type': 'SLA_Binary_Classification'
        }
        
        joblib.dump(metadata, filepath.replace('.json', '_metadata.pkl'))
        print(f"💾 SLA model saved to {filepath}")

def train_sla_pipeline():
    """Complete SLA model training pipeline"""
    
    print("🏭 Loading data for SLA model...")
    
    # Load data
    events_df = pd.read_csv('events_log.csv')
    cases_df = pd.read_csv('cases_table.csv')
    
    # Initialize trainer
    trainer = SLAModelTrainer()
    
    # Prepare SLA data
    training_data, base_feature_cols = trainer.prepare_sla_data(events_df, cases_df)
    print(f"📊 Prepared {len(training_data)} SLA samples")
    print(f"🎯 Target distribution: {training_data['will_breach_sla'].value_counts(normalize=True).to_dict()}")
    
    # Create enhanced features
    X, feature_cols = trainer.create_sla_features(training_data, base_feature_cols)
    y = training_data['will_breach_sla']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"🎯 Training set: {X_train.shape}")
    print(f"🧪 Test set: {X_test.shape}")
    print(f"📊 Features: {len(feature_cols)}")
    
    # Optimize hyperparameters
    trainer.optimize_hyperparameters(X_train, y_train, n_trials=30)
    
    # Train model
    trainer.train_model(X_train, y_train, X_test, y_test)
    
    # Evaluate model
    metrics, predictions = trainer.evaluate_model(X_test, y_test)
    
    # Save model
    trainer.save_model()
    
    return trainer, metrics

if __name__ == "__main__":
    trainer, metrics = train_sla_pipeline()
    print("\n🎉 SLA model training complete!")
    print(f"📈 Final ROC-AUC: {metrics['roc_auc']:.4f}")
    print(f"🎯 Final F1-Score: {metrics['f1']:.4f}")
